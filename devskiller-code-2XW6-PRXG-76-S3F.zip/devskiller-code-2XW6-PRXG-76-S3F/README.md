# .NET RESTful Blog

## Introduction

You are working on a bloging engine with your team. The work is almost completed, but you still have to finish two steps.

## Problem Statement

Your job is to implement two methods:

1. `TagManager.UntagPost` - This method should delete from repository a tag that is related to specific `postId`. `ArgumentException` should be thrown when arguments are not valid: tag is empty, post does not exists, or tag isn't related to post.
2. `PostManager.Get` - This method should query repository and return post by given `Id`, or throw `ArgumentException` if it does not exists. The result should be mapped with automapper to `PostDetailsModel` type.

## Hints
1. Check the source code for comments with detailed requirements. Write a program to execute integration tests for a basic verification of your solution. 
2. Keep in mind that your solution will be comprehensively tested with additional tests that will check if all requirements have been met.
3. To **run integration tests** on your local environment, you may be required to run them as `administrator` or/and in Visual Studio go to `Tools` | `Options` | `Test` | `General` and uncheck the `For improved performance, only use test adapters in test assembly folders or as specified in runsettings file` checkbox.